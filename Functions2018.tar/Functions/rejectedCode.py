def whatWasIthinking_sigmaClipper(chans,flux):
    peakS=np.max(flux)
    nChan=len(flux)
    meanS=np.sum(flux)/float(len(chans))                  #of all channels
    medianS=np.median(flux)
    print "\n >>> Mean flux across all channels: "+str(meanS)
    print " >>> Median flux across all channels: "+str(medianS)
    print " >>> Peak flux across all channels: "+str(peakS)
    print " >>> SNR = "+str(peakS/meanS)

    j=0 #--- counter for none line channels
    k=0 #--- counter for line channels
    pseudo_rms_tot=0.0

    #--- Calculate rms for all channels below cliplevel x median value
    for i in flux:
        if i >(meanS):
            k=k+1
        else:
            j=j+1
            pseudo_rms_tot=pseudo_rms_tot+(i*i)

    print " >>> "+str(k)+" channels above mean over all channels"
    pseudo_rms=np.sqrt(pseudo_rms_tot/j)
    print " >>> Pseudo rms: "+str(pseudo_rms)

    """ Now exclude the high channels and repeat until SNR becomes 1.0"""


"""--------------------------------------------------------------------"""

def old_sigmaClipper(chans,flux,cliplevel=2.0):
    peakS=np.max(flux)
    nChan=len(flux)
    meanS=np.sum(flux)/float(len(chans))                  #of all channels
    medianS=np.median(flux)
    print "\n >>> Mean flux across all channels: "+str(meanS)
    print " >>> Median flux across all channels: "+str(medianS)
    print " >>> Peak flux across all channels: "+str(peakS)
    print " >>> SNR = "+str(peakS/meanS)
    j=0 #--- counter for none line channels
    k=0 #--- counter for line channels
    q=0
    pseudo_rms_tot=0.0

    #--- Calculate rms for all channels below cliplevel x median value
    for i in flux:
        if i >(cliplevel*medianS):
            k=k+1
        else:
            j=j+1
            pseudo_rms_tot=pseudo_rms_tot+(i*i)
        q=q+1

    print " >>> "+str(k)+" channels above "+str(cliplevel)+" * median over all channels"
    print j
    pseudo_rms=np.sqrt(pseudo_rms_tot/j)
    print " >>> Pseudo rms: "+str(pseudo_rms)

    print "\n >>> Running highRMS pass, looking for emission above"
    print " >>> "+str(cliplevel+1.0)+"*Pseudo rms"
    highLineChans,baseLineUse=highRMSpass(chans,flux,cliplevel,pseudo_rms)

    print "\n >>> Running lowRMS pass, looking for emission between"
    print " >>> "+str(cliplevel+1.0)+" and "+str(cliplevel)+"*Pseudo rms"
    lowLineChans,baseLineUse=lowRMSpass(chans,flux,cliplevel,pseudo_rms,baseLineUse)


    return highLineChans,lowLineChans,baseLineUse

def highRMSpass(chans,flux,cliplevel,sigmaClipRMS):
    #--- Calculate rms for all channels above cliplevel+1*sigmaClipRMS ---#
    #--- if a channel is above cliplevel+1*sigmaClipRMS then make --------#
    #--- line_regions == line_val ----------------------------------------#
    line_regions_highrms=np.zeros(len(chans))
    baseline_use_regions=np.zeros(len(chans))
    line_val_highrms=1.0
    v=0
    l=0
    for ii in flux:
        if ii >((cliplevel+1.0)*sigmaClipRMS):
            l=l+1
            line_regions_highrms[v]=line_val_highrms
            baseline_use_regions[v]=0.0
        else:
            baseline_use_regions[v]=flux[v] #--- Keep values of flux below (cliplevel+1.0)*sigmaClipRMS
        v=v+1
    print " >>> Found "+str(l)+" channels above 3.0*Pseudo rms"
    #--- Assess line_regions to exclude single channels ---#
    w=0
    for lr in line_regions_highrms:
        if lr == line_val_highrms:
            if w==(len(chans)-1):
                if line_regions_highrms[w-1]==0.0:
                    line_regions_highrms[w]=0.0
            elif w==0:
                if line_regions_highrms[w+1]==0.0:
                    line_regions_highrms[w]=0.0
            else:
                if line_regions_highrms[w-1]==0.0 and line_regions_highrms[w+1]==0.0:
                    line_regions_highrms[w]=0.0
        w=w+1

    #print baseline_use_regions
    return line_regions_highrms, baseline_use_regions

def lowRMSpass(chans,flux,cliplevel,sigmaClipRMS,baseline_use_regions):
    #--- Calculate rms for all channels between cliplevel*sigmaClipRMS ---#
    #--- and cliplevel+1*sigmaClipRMS -------#
    #--- == line_val ---------------------------------------------------#
    line_regions_lowrms=np.zeros(len(chans))
    line_val_lowrms=0.8

    vv=0
    ll=0
    for iii in flux:
        if iii >(cliplevel*sigmaClipRMS) and iii <=((cliplevel+1.0)*sigmaClipRMS) :
            ll=ll+1 #--- count the number of line
            line_regions_lowrms[vv]=line_val_lowrms
            baseline_use_regions[vv]=0.0


        vv=vv+1
    print " >>> Found "+str(ll)+" channels between 2.0 and 3.0*Pseudo rms"
    #--- Assess line_regions to exclude single channels ---#
    ww=0

    for llr in line_regions_lowrms:
        if llr == line_val_lowrms:
            if ww==(len(chans)-1):
                if line_regions_lowrms[ww-1]==0.0:
                    line_regions_lowrms[ww]=0.0
            elif ww==0:
                if line_regions_lowrms[ww+1]==0.0:
                    line_regions_lowrms[ww]=0.0
            else:
                if  line_regions_lowrms[ww-1]==0.0 and line_regions_lowrms[ww+1]==0.0:
                    line_regions_lowrms[ww]=0.0
        ww=ww+1

    #print " >>> New Pseudo rms: "+str(np.sqrt((np.sum(baseline_use_regions[np.nonzero(baseline_use_regions)])/float(len(baseline_use_regions)))))

    return line_regions_lowrms, baseline_use_regions
