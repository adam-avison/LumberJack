obsid= [0,0,0,0,0,1,1,1,1,1,2,2,2,2]
scan_numbers=[1,2,3,4,5,6,7,8,9,10,11,12,13,14]


obsID=0
x=0
for scanno in scan_numbers:
       if obsID==obsid[x]:
                print scanno, obsID
       else: 
                obsID+=1
                print 'eeer'
       x=x+1     

print "\nwhile\n"
obsID=0
y=0
while(y<len(scan_numbers)):

        scanno=scan_numbers[y]
        if obsID==obsid[y]:
                print scanno, obsID
        else: 
                y-=1
                obsID+=1
                print 'eeer'
        y+=1
