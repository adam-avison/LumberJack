import re
import numpy as np
from astroFUNCS import *

position="12:13:14.000"+"\t"+"-48:47:30.6"#Tab delimit
Deg=RADec_to_Deg(position)

raRad=float(re.split('\s+',Deg)[0])/(180.0/np.pi)
decRad=float(re.split('\s+',Deg)[1])/(180.0/np.pi)

print raRad, decRad
