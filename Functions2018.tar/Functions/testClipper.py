import numpy as np
import re
import matplotlib.pyplot as plt
import random

def randCol():

    cols=['b', 'g', 'r', 'c', 'm', 'y', 'k','pink','orange','purple','RoyalBlue']

    col=cols[random.randint(0,len(cols)-1)]
    
    return col


def testPlots(x,y,col='blue',mar='',lin='-'):
    fig = plt.figure(1, figsize=[7,7])
    ax = fig.add_subplot(1, 1, 1)
    ax.plot(x,y,color=col,linestyle=lin,marker=mar)

def loadFromText(txtfile):

    chan,S=np.loadtxt(txtfile,unpack=True)
    return chan,S

def sigmaClipper(ch,S):
    SNR=1000.0

    while SNR>1.0:
        peakS=np.max(S)
        print peakS,'!!!!'
        nChan=len(S[np.nonzero(S)])
        if nChan==0:
            print "\n >>> SNR of "+str(SNR)+" reached... stopping now"
            SNR=1.0
            newS=tmpS
        else:
            print nChan
            meanS=np.sum(S[np.nonzero(S)])/float(nChan)                  #of all channels
            medianS=np.median(S[np.nonzero(S)])
            stdS=np.std(S[np.nonzero(S)])
            SNR=peakS/meanS
            print "\n >>> Mean flux across all channels: "+str(meanS)
            print " >>> Median flux across all channels: "+str(medianS)
            print " >>> Peak flux across all channels: "+str(peakS)
            print " >>> SNR = "+str(SNR)
    
            tru=np.where(S<0.70*peakS)[0]
            newS=np.zeros(len(S))
            tmpS=S
            for x in tru:
                newS[x]=S[x]

            S=[]
            S=newS

            print S
    
    return ch, newS, meanS, stdS


def plotGauss(stdDev,mean,S):
    sRang=np.arange(np.min(S),np.max(S),1.0e-6)
    a=1.0/(stdDev*(np.sqrt(2*np.pi)))
    expon=((sRang-mean)**2.0)/(2.0*(stdDev**2.0))
    gau=a*np.exp(-1.0*expon)
    return sRang,gau
    
ch,S=loadFromText('../testData/full_sdc335_SPW0_4_8_12spec.txt')
#ch,S=loadFromText('../testData/synthe2.txt')

testPlots(ch,S)


ch,newS,meanS,stDevS=sigmaClipper(ch,S)


testPlots(ch,newS,randCol(),'x')

figH = plt.figure(2, figsize=[7,7])
axH = figH.add_subplot(1, 1, 1)
axH.hist(newS[np.nonzero(newS)],normed=True)
#print np.histogram(newS[np.nonzero(newS)])
sR,Gau=plotGauss(stDevS,meanS,newS[np.nonzero(newS)])
axH.plot(sR,Gau,'r')

    
plt.show()
