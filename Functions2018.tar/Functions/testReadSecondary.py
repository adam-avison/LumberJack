import numpy as np
import re



secondaryFile='testSecond.txt'

secondarySources=np.genfromtxt(secondaryFile, dtype=None, names=['souNum','secRA','secDec','secBmaj','secBmin','secPA'])

for x in range(len(secondarySources['souNum'])):
    source_no=re.split('source',secondarySources['souNum'][x])[1]
    position=secondarySources['secRA'][x]+'\t'+secondarySources['secDec'][x]
    thisBmaj=str(secondarySources['secBmaj'][x])+'arcsec'
    thisBmin=str(secondarySources['secBmin'][x])+'arcsec'
    thisPA=str(secondarySources['secPA'][x])+'deg'

    print source_no, position, thisBmaj, thisBmin, thisPA
